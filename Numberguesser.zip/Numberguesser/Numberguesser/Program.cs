﻿using System.CodeDom.Compiler;
using System.Runtime.CompilerServices;
using System;
using System.Media;

namespace Numberguesser
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int guess;
            int guesses = 0;
            bool guessing;
            int rndNum;
            bool playing;
            char ans;
            int HighscoreInt = 1000;


            Console.WriteLine("---------- Numberguesser ---------");
            Console.WriteLine("Guess the number between 1 and 100");
            Console.WriteLine("----------------------------------");
            
            playing = true;
            while(playing)
            {
                rndNum = Generator.generateN();
                guessing = true;
                while (guessing)
                {
                    try
                    {
                        Console.Write("Guess:");
                        guess = Convert.ToInt32(Console.ReadLine());
                        if (rndNum == guess)
                        {
                            guessing = false;
                            guesses++;
                            if (guesses == 1)
                            {
                                Console.WriteLine("You guessed the number after 1 attempt!");
                                Console.WriteLine("----------------------------------");
                            }
                            else
                            {
                                Console.WriteLine("You guessed the number after " + guesses + " attempts!");
                                Console.WriteLine("----------------------------------");
                            }

                            if(guesses < HighscoreInt)
                            {
                                HighscoreInt = guesses;
                            }

                            Console.WriteLine("Highscore: " + HighscoreInt);
                            Console.WriteLine("----------------------------------");
                            Console.WriteLine("||||||||||||||||||||||||||||||||||");
                            Console.WriteLine("----------------------------------");
                        }
                        else
                        {
                            if (rndNum < guess)
                            {
                                guesses++;
                                Console.WriteLine("The number is smaller");
                                Console.WriteLine("----------------------------------");
                            }
                            else
                            {
                                guesses++;
                                Console.WriteLine("The number is bigger");
                                Console.WriteLine("----------------------------------");
                            }
                        }   
                    }
                    catch
                    {
                        Console.WriteLine("Invalid Input, try again");
                        Console.WriteLine("----------------------------------");
                    }
                }

                bool again = true;
                while (again)
                {
                    Console.Write("Do you want to play again? (y|n)");
                    try
                    {
                        ans = Convert.ToChar(Console.ReadLine());
                        if(ans != 'y' & ans != 'n')
                        {
                            throw new Exception();
                        }

                        if(ans == 'y')
                        {
                            again= false;
                            guesses = 0;
                        }
                        else
                        {
                            again = false;
                            playing = false;
                        }
                        Console.WriteLine("----------------------------------");
                    }
                    catch
                    {
                        Console.WriteLine("Invalid Input, try again");
                        Console.WriteLine("----------------------------------");
                    }
                }
            }
        }
        public class Generator
        {
            public static int generateN()
            {
                Random rnd = new Random();
                int num = rnd.Next(1, 101);
                return num;
            }
        }
    }
}